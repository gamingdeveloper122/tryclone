# PHANTOM BY NULLDASH — Complete Website Clone (Single-Spacebar Unlock)

Yeh folder `https://ph4nt0m.lol/` ka mukammal working frontend aur mock-backend workspace hai.

## Access Key / Unlock Logic
- **Valid Key:** Sirf ek **single space character (`" "`)**.
- Input box mein keyboard se **ek baar Spacebar** dabayein aur **`UNLOCK`** button click karein (ya **`Enter`** dabayein) — bina kisi error ke tool unlock aur open ho jayega.
- Input aur server dono jagah se `.trim()` aur `PHTM-XXXX-XXXX-XXXX` formatting hata di gayi hai taake single space (`" "`) ko empty na samjha jaye.

## File Structure

```text
phantom-clone/
├── index.html        # Modular HTML5 shell (css/ aur js/ folders ke saath)
├── standalone.html   # Single-file All-in-One HTML (CSS + JS ek hi file mein embedded!)
├── css/
│   └── styles.css    # Complete design system (--ph-* tokens, polygon cuts, HUD, sliders, RTL)
├── js/
│   ├── i18n.js       # 215-key translation dictionary (English, Thai, Arabic RTL)
│   ├── data.js       # Brand configs, SVG icons, feature defaults & single-space validator
│   └── app.js        # Complete SPA state machine, KeyGate, Dashboard tabs, drag sliders & API
├── server.js         # Optional zero-dependency Node.js server (/api/redeem, SSE /api/events, etc.)
└── README.md         # Setup guide
```
