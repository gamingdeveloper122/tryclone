// ============================================================================
// PHANTOM BY NULLDASH — Complete Interactive Frontend Engine (Vanilla JS)
// ============================================================================

(() => {
  const {
    BRANDS,
    ICONS,
    PHANTOM_GHOST_PATH,
    MARKER_TYPES,
    DEFAULT_UI,
    UPDATE_NOTES,
    ANNOUNCEMENTS,
    APP_STORE_LINKS,
    mergeFeatures,
    createProfile,
    resolveKeyPreset,
    formatKey,
    isKeyComplete,
    formatAngle,
    formatDate,
    formatDuration,
    relativeTime,
    detectOS
  } = window.PHANTOM_DATA;

  const { LANGS } = window.PHANTOM_I18N;

  // --------------------------------------------------------------------------
  // Global Application State
  // --------------------------------------------------------------------------
  const STORAGE_KEYS = {
    LANG: "ph_lang",
    SESSION: "ph_session_v1",
    SEEN_ANNOUNCE: "ph_seen_announce",
    KICKED: "ph_kicked",
    BRAND: "ph_brand"
  };

  const state = {
    lang: "en",
    brand: "phantom",
    rootView: "gate",      // "gate" | "dashboard" | "maintenance"
    gateMaintenance: false,
    kickedBanner: false,
    keyInput: "",
    keyError: null,
    keyShake: false,
    unlocking: false,

    // Dashboard state
    me: null,
    tab: "home",           // "home" | "features" | "manage"
    subView: null,         // null | "guide" | "notes"
    langMenuOpen: false,
    bellModalOpen: false,
    seenAnnounceId: 0,
    keyCopied: false,
    setupLinkCopied: false,
    connectBusy: false,
    connectHint: null,
    needAppFallback: false,
    mintedUrl: "https://ph4nt0m.lol/sub/phtm-demo-token",
    savingFeatureId: null,
    failedFeatureId: null,

    // Demo panel state
    demoPanelOpen: false,
    presetName: "gate",
    os: detectOS()
  };

  let tickTimer = null;
  let eventSource = null;

  // --------------------------------------------------------------------------
  // Translation & Brand Helpers
  // --------------------------------------------------------------------------
  function getT() {
    const dict = window.PHANTOM_I18N[state.lang] || window.PHANTOM_I18N.en;
    return { ...window.PHANTOM_I18N.en, ...dict };
  }

  function getBrandObj() {
    return BRANDS.find((b) => b.slug === state.brand) || BRANDS[0];
  }

  function setLang(langId) {
    if (!window.PHANTOM_I18N[langId]) return;
    state.lang = langId;
    state.langMenuOpen = false;
    document.documentElement.lang = langId;
    document.documentElement.dir = langId === "ar" ? "rtl" : "ltr";
    try {
      localStorage.setItem(STORAGE_KEYS.LANG, langId);
    } catch {}
    render();
  }

  function setBrand(brandSlug) {
    state.brand = brandSlug;
    document.documentElement.setAttribute("data-brand", brandSlug);
    try {
      localStorage.setItem(STORAGE_KEYS.BRAND, brandSlug);
    } catch {}
    render();
  }

  function persistSession() {
    try {
      if (state.rootView === "gate" || !state.me) {
        localStorage.removeItem(STORAGE_KEYS.SESSION);
      } else {
        localStorage.setItem(
          STORAGE_KEYS.SESSION,
          JSON.stringify({
            rootView: state.rootView,
            presetName: state.presetName,
            me: state.me
          })
        );
      }
    } catch {}
  }

  // --------------------------------------------------------------------------
  // HTML Escaping & Icon Rendering Helpers
  // --------------------------------------------------------------------------
  function esc(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function iconSvg(name, { size = 20, strokeWidth = 2.2, flip = false, className = "" } = {}) {
    const cls = [flip ? "ph-flip" : "", className].filter(Boolean).join(" ");
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="square" class="${cls}" aria-hidden="true">${ICONS[name] || ""}</svg>`;
  }

  function phantomMarkSvg({ size = 104, color = "var(--ph-accent)", glow = true } = {}) {
    const filterStyle = glow
      ? `filter:drop-shadow(0 0 ${Math.round(size / 5)}px var(--ph-accent-glow));`
      : "";
    return `<svg viewBox="0 0 100 100" width="${size}" height="${size}" role="img" aria-label="logo" style="${filterStyle}"><path d="${PHANTOM_GHOST_PATH}" fill="${color}" fill-rule="evenodd"></path></svg>`;
  }

  function brandMarkHtml(size = "xl", showTitle) {
    const dims = { xl: [180, 46], lg: [170, 42], md: [104, 26] }[size] || [180, 46];
    const [markPx] = dims;
    const displayTitle = showTitle ?? size === "xl";
    const brand = getBrandObj();
    return `
      <div style="display:flex;flex-direction:column;align-items:center;gap:22px">
        ${phantomMarkSvg({ size: markPx, glow: true })}
        ${
          displayTitle
            ? `<div dir="ltr" style="font:var(--ph-type-wordmark);letter-spacing:var(--ph-track-wordmark);margin-inline-end:-.16em;text-transform:uppercase">${esc(brand.name)}</div>`
            : ""
        }
      </div>
    `;
  }

  function spinnerHtml(size = 16) {
    return `<span class="ph-spinner" style="--s:${size}px" aria-hidden="true"></span>`;
  }

  function statusPillHtml(text, tone) {
    const toneCls = tone ? ` ph-status--${tone}` : "";
    return `<span class="ph-status ph-cut-xs${toneCls}" role="status">${esc(text)}</span>`;
  }

  function tagHtml(label, tone, size) {
    const cls = [
      "ph-tag ph-cut-xs",
      tone ? `ph-tag--${tone}` : "",
      size === "lg" ? "ph-tag--lg" : ""
    ]
      .filter(Boolean)
      .join(" ");
    return `<span class="${cls}">${esc(label)}</span>`;
  }

  function noticeHtml({ tone = "info", title, bodyHtml }) {
    return `
      <div class="ph-notice ph-cut-sm ph-notice--${tone}" role="status">
        <div class="ph-notice__inner ph-cut-sm">
          <span class="ph-notice__dot"></span>
          <div style="display:flex;flex-direction:column;gap:4px;flex:1;min-width:0">
            ${title ? `<div class="ph-notice__title">${esc(title)}</div>` : ""}
            <div class="ph-notice__body">${bodyHtml}</div>
          </div>
        </div>
      </div>
    `;
  }

  function switchHtml({ checked, saving = false, size = "md", asIndicator = false, idAttr = "" }) {
    const tag = asIndicator ? "span" : "button";
    const cls = `ph-switch ph-cut-xs${size === "sm" ? " ph-switch--sm" : ""}`;
    return `<${tag} ${idAttr} role="switch" aria-checked="${Boolean(checked)}" ${saving ? 'aria-busy="true"' : ""} class="${cls}">
      <span class="ph-switch__knob">${saving ? spinnerHtml(12) : ""}</span>
    </${tag}>`;
  }

  // --------------------------------------------------------------------------
  // Shared Header & Notification Bell Modal
  // --------------------------------------------------------------------------
  function headerHtml({ title = "", showBack = false, showBell = false }) {
    const t = getT();
    const curLang = LANGS.find((l) => l.id === state.lang) || LANGS[0];
    const latestId = ANNOUNCEMENTS.length ? ANNOUNCEMENTS[0].id : 0;
    const hasUnread = latestId > state.seenAnnounceId;

    return `
      <header class="ph-header" style="z-index:21">
        ${
          showBack
            ? `<button class="ph-iconbtn ph-cut-xs" data-action="nav-back" aria-label="${esc(t.back)}">${iconSvg("back", { size: 20, strokeWidth: 2.6, flip: true })}</button>`
            : ""
        }
        <h1 class="ph-header__title ph-title" style="margin:0">${esc(title)}</h1>
        ${
          showBell
            ? `<button class="ph-iconbtn ph-cut-xs ph-bell" data-action="open-bell" aria-label="${esc(t.n_bell)}">
                ${iconSvg("bell", { size: 19, strokeWidth: 2.4 })}
                ${hasUnread ? `<span class="ph-bell__dot" aria-hidden="true"></span>` : ""}
              </button>`
            : ""
        }
        <button class="ph-lang ph-cut-xs" data-action="toggle-lang-menu" aria-haspopup="menu" aria-expanded="${state.langMenuOpen}">
          ${iconSvg("globe", { size: 15, strokeWidth: 2 })}
          <span>${esc(curLang.short)}</span>
        </button>
        ${
          state.langMenuOpen
            ? `<div class="ph-menu ph-cut-sm" role="menu">
                ${LANGS.map(
                  (l) => `
                  <button role="menuitemradio" aria-checked="${l.id === state.lang}" aria-current="${l.id === state.lang}" dir="${l.dir}" class="ph-menu__item ph-cut-xs" data-set-lang="${l.id}">
                    <span>${esc(l.label)}</span>
                    ${l.id === state.lang ? iconSvg("check", { size: 18, strokeWidth: 2.6 }) : ""}
                  </button>`
                ).join("")}
              </div>`
            : ""
        }
      </header>
      ${
        state.langMenuOpen
          ? `<div style="position:absolute;inset:0;z-index:20" data-action="close-lang-menu"></div>`
          : ""
      }
      ${showBell && state.bellModalOpen ? bellModalHtml() : ""}
    `;
  }

  function bellModalHtml() {
    const t = getT();
    const latestId = ANNOUNCEMENTS.length ? ANNOUNCEMENTS[0].id : 0;
    const hasUnread = latestId > state.seenAnnounceId;

    return `
      <div class="ph-scrim ph-scrim--center" data-action="close-bell">
        <div class="ph-modal ph-cut-md" role="dialog" aria-modal="true" aria-label="${esc(t.n_title)}" data-stop-prop="true">
          <div class="ph-modal__head">
            <span class="ph-modal__title ph-ellipsis">${esc(t.n_title)}</span>
            <button class="ph-iconbtn ph-cut-xs" data-action="close-bell" aria-label="${esc(t.n_close)}" style="width:38px;height:38px">
              ${iconSvg("close", { size: 18, strokeWidth: 2.6 })}
            </button>
          </div>
          <div class="ph-modal__body">
            ${
              ANNOUNCEMENTS.length === 0
                ? `<div class="ph-notify__empty">${esc(t.n_empty)}</div>`
                : ANNOUNCEMENTS.map((item) => {
                    const tone = item.level === "warn" || item.level === "update" ? item.level : "info";
                    const unread = item.id > state.seenAnnounceId;
                    return `
                      <div class="ph-notify ph-cut-sm ph-notify--${tone}" ${unread ? 'data-unread=""' : ""}>
                        <div class="ph-notify__top">
                          <span class="ph-notify__title">${esc(item.title)}</span>
                          ${unread ? `<span class="ph-tag ph-cut-xs ph-tag--new">${esc(t.tag_new)}</span>` : ""}
                        </div>
                        ${item.body ? `<div class="ph-notify__body">${esc(item.body)}</div>` : ""}
                      </div>
                    `;
                  }).join("")
            }
          </div>
          ${
            ANNOUNCEMENTS.length > 0 && hasUnread
              ? `<button class="ph-btn ph-cut-sm ph-btn--block" data-action="close-bell">${esc(t.n_markread)}</button>`
              : ""
          }
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Root View 1: KeyGate (Login / Key Unlock Screen)
  // --------------------------------------------------------------------------
  function renderKeyGate() {
    const t = getT();

    return `
      <div class="ph-viewport">
        <div class="ph-app" style="min-height:100dvh;width:100%;display:flex;flex-direction:column;position:relative;overflow:hidden">
          ${
            state.gateMaintenance
              ? `<div class="ph-banner" role="status"><span class="ph-banner__icon ph-cut-xs">!</span><span>${esc(t.banner)}</span></div>`
              : ""
          }
          ${headerHtml({ title: "", showBack: false, showBell: false })}
          <div style="position:absolute;top:-120px;left:50%;transform:translateX(-50%);opacity:0.035;pointer-events:none;z-index:0">
            ${phantomMarkSvg({ size: 640, glow: false })}
          </div>
          <main style="position:relative;z-index:1;flex:1;display:flex;flex-direction:column;padding:0 20px">
            ${
              state.kickedBanner
                ? `<div style="padding-top:8px">
                    ${noticeHtml({
                      tone: "warn",
                      title: t.kicked,
                      bodyHtml: `<span style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
                        <span>${esc(t.kickedBody)}</span>
                        <button data-action="dismiss-kicked" aria-label="${esc(t.back)}" style="flex:none;background:transparent;border:0;color:var(--ph-text-5);cursor:pointer;padding:0;margin-top:-2px">
                          ${iconSvg("close", { size: 16, strokeWidth: 2.6 })}
                        </button>
                      </span>`
                    })}
                  </div>`
                : ""
            }
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px">
              ${brandMarkHtml("xl", true)}
              <div class="ph-label" style="font-size:11px;color:var(--ph-text-6);text-align:center">
                ${esc(t.tagline)}
              </div>
            </div>
          </main>
          <form id="ph-gate-form" style="position:relative;z-index:1;padding:0 20px 22px;display:flex;flex-direction:column;gap:14px">
            <div style="display:flex;flex-direction:column;gap:10px">
              <div class="ph-label" style="display:flex;align-items:center;gap:8px">
                <span style="width:6px;height:6px;background:var(--ph-accent)"></span>
                ${esc(t.accessKey)}
              </div>
              <div class="ph-keyinput ph-cut-sm" ${state.keyError ? 'data-error=""' : ""} ${state.keyShake ? 'data-shake=""' : ""}>
                <div class="ph-keyinput__inner ph-cut-sm">
                  <input
                    id="ph-key-field"
                    type="text"
                    value="${esc(state.keyInput)}"
                    placeholder=""
                    autocapitalize="off"
                    spellcheck="false"
                    autocomplete="off"
                    aria-label="${esc(t.accessKey)}"
                    aria-invalid="${Boolean(state.keyError)}"
                    autofocus
                  />
                  <button type="button" class="ph-keyinput__paste ph-cut-xs" data-action="paste-key">${esc(t.paste)}</button>
                </div>
              </div>
              ${state.keyError ? `<div class="ph-fielderror" role="alert">${esc(state.keyError)}</div>` : ""}
            </div>
            <button type="submit" class="ph-btn ph-cut-sm ph-btn--primary ph-btn--block" ${state.unlocking ? 'aria-busy="true"' : ""}>
              ${state.unlocking ? spinnerHtml(18) : ""}
              <span>${esc(state.unlocking ? t.unlocking : t.unlock)}</span>
            </button>
            <div style="display:flex;flex-direction:column;gap:4px;text-align:center">
              <span style="font:var(--ph-type-body);color:var(--ph-text-4)">${esc(t.noKey)}</span>
              <span style="font:var(--ph-type-body-sm);color:var(--ph-text-7)">${esc(t.timeStarts)}</span>
            </div>
          </form>
          <div class="ph-scanlines"></div>
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Root View 2: Maintenance Hold View
  // --------------------------------------------------------------------------
  function renderMaintenance() {
    const t = getT();
    return `
      <div class="ph-viewport">
        <div class="ph-app" style="min-height:100dvh;width:100%;display:flex;flex-direction:column;position:relative">
          ${headerHtml({ title: "", showBack: false, showBell: false })}
          <main style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:0 20px">
            <div style="filter:drop-shadow(0 0 34px color-mix(in oklch, var(--ph-warn) 45%, transparent))">
              ${phantomMarkSvg({ size: 170, glow: false })}
            </div>
            ${tagHtml(t.maint, "paused", "lg")}
            <p style="font:var(--ph-type-body-lg);color:var(--ph-text-4);text-align:center;max-width:280px">
              ${esc(t.holdBody)}
            </p>
            <button class="ph-btn ph-cut-sm ph-btn--block" style="max-width:280px" data-action="logout">
              <span>${esc(t.logout)}</span>
            </button>
          </main>
          <div class="ph-scanlines"></div>
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Dashboard Sub-Components: Home HUD, Setup Wizard, Features, Manage, Notes
  // --------------------------------------------------------------------------
  function timeRingHtml({ progress = 0, color = "var(--ph-accent)", glow, height = 332, innerHtml }) {
    const activeTicks = Math.round(60 * Math.max(0, Math.min(1, progress)));
    let activePath = "";
    let inactivePath = "";
    for (let i = 0; i < 60; i++) {
      const angle = (i / 60) * 2 * Math.PI - Math.PI / 2;
      const innerR = i % 5 ? 129 : 119;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const seg =
        "M" +
        (150 + 141 * cos).toFixed(1) +
        " " +
        (150 + 141 * sin).toFixed(1) +
        "L" +
        (150 + innerR * cos).toFixed(1) +
        " " +
        (150 + innerR * sin).toFixed(1);
      if (i < activeTicks) activePath += seg;
      else inactivePath += seg;
    }

    const bgGrad = `radial-gradient(circle at 50% 50%, ${
      glow || `color-mix(in oklch, ${color} 16%, transparent)`
    } 0%, transparent 64%)`;

    return `
      <div class="ph-hud" style="height:${height}px;background:${bgGrad}">
        <span class="ph-hud__corner"></span>
        <span class="ph-hud__corner"></span>
        <span class="ph-hud__corner"></span>
        <span class="ph-hud__corner"></span>
        <svg viewBox="0 0 300 300" width="300" height="300" style="position:absolute;left:50%;top:50%;margin:-150px 0 0 -150px" aria-hidden="true">
          ${inactivePath ? `<path d="${inactivePath}" stroke="#1f1f24" stroke-width="3.2" fill="none"></path>` : ""}
          ${activePath ? `<path d="${activePath}" stroke="${color}" stroke-width="3.2" fill="none"></path>` : ""}
        </svg>
        <div style="position:relative;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;max-width:200px">
          ${innerHtml}
        </div>
      </div>
    `;
  }

  function renderHomeStatus() {
    const t = getT();
    const me = state.me;
    const now = Date.now();
    const isActive = me.status === "active";
    const isExpired = me.status === "expired";
    const isUnact = me.status === "unactivated";
    const isPaused = me.status === "paused";
    const hasConnected = isActive && me.last_seen_at != null;

    const remainingMs = Math.max(0, (me.expires_at ? new Date(me.expires_at).getTime() : 0) - now);
    const lockUntilMs = me.lock_until ? new Date(me.lock_until).getTime() : 0;
    const isLocked = lockUntilMs > now;

    const pill = isLocked
      ? { tone: "bad", text: t.sLocked }
      : isActive
      ? me.online
        ? { tone: "ok", text: t.sConnected }
        : { tone: undefined, text: t.sOffline }
      : isExpired
      ? { tone: "bad", text: t.sExpired }
      : isPaused
      ? { tone: "warn", text: t.sPaused }
      : { tone: "bad", text: t.sUnact };

    const refreshedLabel = me.last_seen_at
      ? t.lastRefreshed.replace("{t}", relativeTime(new Date(me.last_seen_at).getTime(), t, now))
      : t.never;

    const progress = hasConnected && !isExpired ? Math.min(1, remainingMs / (30 * 86400 * 1000)) : 0;
    const ringGlow =
      isExpired || isUnact
        ? "color-mix(in oklch, var(--ph-bad) 10%, transparent)"
        : isActive && me.online
        ? "color-mix(in oklch, var(--ph-ok) 16%, transparent)"
        : undefined;

    let heroText = "—";
    let heroSub = "";
    let heroColor = "var(--ph-text-1)";

    if (isExpired) {
      heroText = t.expiredWord.toUpperCase();
      heroColor = "var(--ph-bad-text)";
    } else if (isPaused) {
      heroText = t.sPaused.toUpperCase();
      heroColor = "var(--ph-warn)";
    } else if (isUnact) {
      heroText = "—";
      heroSub = t.notActiveLbl;
    } else if (hasConnected) {
      heroText = formatDuration(remainingMs, t);
      heroSub = t.timeLeft;
    } else {
      heroText = "—";
      heroSub = t.startsOnConnect;
    }

    // Lockout countdown formatting
    let lockBannerHtml = "";
    if (isLocked) {
      const sec = Math.max(0, Math.floor((lockUntilMs - now) / 1000));
      const lh = Math.floor(sec / 3600);
      const lm = Math.floor((sec % 3600) / 60);
      const ls = sec % 60;
      const pad = (n) => String(n).padStart(2, "0");
      const timerStr = lh > 0 ? `${lh}:${pad(lm)}:${pad(ls)}` : `${pad(lm)}:${pad(ls)}`;
      const nextPenalty = (me.strikes || 1) <= 1 ? t.dur30m : t.dur6h;

      lockBannerHtml = `
        <div class="ph-notice ph-cut-sm ph-notice--bad" role="status">
          <div class="ph-notice__inner ph-cut-sm" style="flex-direction:column;gap:8px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
              <span class="ph-notice__title">${esc(t.sLocked)}</span>
              <span class="ph-display" dir="ltr" data-live-lock="true" style="font-size:20px;color:var(--ph-bad-text)">${timerStr}</span>
            </div>
            <div class="ph-notice__body">${esc(t.lockedBody)}</div>
            <div class="ph-notice__body">${esc(t.lockedNext.replace("{t}", nextPenalty))}</div>
            <div class="ph-notice__body" style="color:var(--ph-text-6)">${esc(t.lockedNotYou)}</div>
          </div>
        </div>
      `;
    }

    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:4px 0 2px">
          ${statusPillHtml(pill.text, pill.tone)}
          <span class="ph-label" style="color:var(--ph-text-7)">${esc(refreshedLabel)}</span>
        </div>

        ${lockBannerHtml}

        ${timeRingHtml({
          progress,
          color: "var(--ph-accent)",
          glow: ringGlow,
          innerHtml: `
            ${brandMarkHtml("md", false)}
            <div class="ph-ring__time" data-live-ring-time="true" style="color:${heroColor}">${esc(heroText)}</div>
            ${heroSub ? `<div class="ph-label" style="font-size:10.5px;color:var(--ph-text-6)">${esc(heroSub)}</div>` : ""}
          `
        })}

        ${isExpired ? noticeHtml({ tone: "bad", title: t.n_expired_t, bodyHtml: esc(t.n_expired_b) }) : ""}
        ${
          me.thaw
            ? noticeHtml({ tone: "warn", title: t.setupThawT, bodyHtml: esc(t.setupThawB) })
            : isPaused
            ? noticeHtml({ tone: "warn", title: t.n_paused_t, bodyHtml: esc(t.n_paused_b) })
            : ""
        }
        ${isUnact ? noticeHtml({ tone: "bad", title: t.n_unact_t, bodyHtml: esc(t.n_unact_b) }) : ""}

        <button class="ph-keychip ph-cut-sm" data-action="copy-key" ${state.keyCopied ? 'data-copied=""' : ""} aria-label="${esc(t.tapCopy)}">
          <span class="ph-label" style="font-size:10px;color:var(--ph-text-7)">${esc(t.keyLbl)}</span>
          <span class="ph-keychip__value">${esc(me.key)}</span>
          <span class="ph-keychip__action ph-cut-xs">
            ${iconSvg(state.keyCopied ? "check" : "copy", { size: 14, strokeWidth: state.keyCopied ? 3 : 2.4 })}
            ${esc(state.keyCopied ? t.copied : t.tapCopy)}
          </span>
        </button>

        <div style="display:grid;grid-template-columns:repeat(2, minmax(0,1fr));gap:8px">
          <div class="ph-fact ph-cut-sm">
            <span class="ph-label" style="font-size:9.5px;color:var(--ph-text-7)">${esc(t.activated)}</span>
            <span class="ph-fact__value">${me.activated_at ? esc(formatDate(me.activated_at, state.lang)) : "—"}</span>
          </div>
          <div class="ph-fact ph-cut-sm">
            <span class="ph-label" style="font-size:9.5px;color:var(--ph-text-7)">${esc(t.expires)}</span>
            <span class="ph-fact__value">${hasConnected && me.expires_at ? esc(formatDate(me.expires_at, state.lang)) : "—"}</span>
          </div>
        </div>

        <button class="ph-row ph-cut-sm" data-action="open-guide">
          <span class="ph-row__icon ph-cut-xs">${iconSvg("play", { size: 18 })}</span>
          <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
            <span class="ph-row__title">${esc(t.guide)}</span>
            <span class="ph-row__sub">${esc(t.guideSub)}</span>
          </span>
          <span class="ph-row__trail">${iconSvg("chevron", { size: 18, flip: true })}</span>
        </button>
      </div>
    `;
  }

  function renderSetupWizard({ asGuide = false } = {}) {
    const t = getT();
    const me = state.me;
    const isIos = state.os === "ios";
    const storeUrl = isIos ? APP_STORE_LINKS.HIDDIFY_IOS : APP_STORE_LINKS.HIDDIFY_ANDROID;

    const stepCard = (n, active, title, sub, bodyHtml) => `
      <div class="ph-frame ph-cut-md">
        <div class="ph-cut-md" style="padding:16px;display:flex;gap:14px">
          <span class="ph-row__icon ph-cut-xs" dir="ltr" style="flex:none;${active ? "background:var(--ph-accent);color:var(--ph-accent-ink)" : ""}">
            ${String(n).padStart(2, "0")}
          </span>
          <div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;flex-direction:column;gap:3px">
              <span class="ph-row__title" style="${active ? "color:var(--ph-accent-text)" : ""}">${esc(title)}</span>
              <span class="ph-row__sub">${esc(sub)}</span>
            </div>
            ${bodyHtml}
          </div>
        </div>
      </div>
    `;

    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        ${
          !asGuide
            ? `<div style="display:flex;align-items:center;justify-content:space-between;padding:4px 0 2px">
                ${statusPillHtml(t.notConnectedYet)}
              </div>`
            : ""
        }
        <div style="display:flex;flex-direction:column;gap:6px;padding:2px">
          <span class="ph-title" style="font-size:21px">${esc(t.setupTitle)}</span>
          <span class="ph-row__sub">${esc(t.setupIntro)}</span>
        </div>
        ${me?.thaw ? noticeHtml({ tone: "warn", title: t.setupThawT, bodyHtml: esc(t.setupThawB) }) : ""}

        ${stepCard(
          1,
          false,
          t.setup1T,
          t.setup1B,
          `<a class="ph-row ph-cut-sm" href="${esc(storeUrl)}" target="_blank" rel="noreferrer">
            <span class="ph-row__icon ph-cut-xs">${isIos ? "i" : "A"}</span>
            <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
              <span class="ph-row__title">${esc(t.getApp)}</span>
              <span class="ph-row__sub">${isIos ? "App Store" : "Google Play"}</span>
            </span>
            <span class="ph-row__trail">${iconSvg("external", { size: 16, flip: true })}</span>
          </a>`
        )}

        ${stepCard(
          2,
          true,
          t.setup2T,
          t.setup2Hint,
          `
          <button class="ph-btn ph-cut-sm ph-btn--primary ph-btn--block" data-action="connect-sub" ${state.connectBusy ? 'aria-busy="true"' : ""}>
            ${state.connectBusy ? spinnerHtml(18) : iconSvg("plus", { size: 20, strokeWidth: 2.8 })}
            <span>${esc(state.connectBusy ? t.opening : t.setup2Btn)}</span>
          </button>
          ${
            state.connectHint
              ? `<div role="status" style="font:var(--ph-type-body-sm);color:${state.connectHint.bad ? "var(--ph-bad-text)" : "var(--ph-text-5)"}">${esc(state.connectHint.text)}</div>`
              : ""
          }
          ${
            state.needAppFallback
              ? `<button data-action="copy-sub-link" style="align-self:flex-start;background:transparent;border:0;padding:0;color:var(--ph-accent-text);font:var(--ph-type-body-sm);cursor:pointer">
                  ${esc(state.setupLinkCopied ? t.setup2Copied : t.setup2Copy)}
                </button>`
              : ""
          }
          `
        )}

        ${stepCard(
          3,
          false,
          t.setup3T,
          t.setup3B,
          `<span class="ph-row__sub" style="color:var(--ph-text-6)">${esc(t.setupThenPlay)}</span>`
        )}
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Tab 2: Features View (with AimSlider, SpeedSlider, AngleSlider, ChipGroup)
  // --------------------------------------------------------------------------
  function aimY(v) {
    return 10 + (1 - (v - 0.5) / 0.5) * 168;
  }

  function polyPoints(coords) {
    return coords.map(([x, yVal]) => `${x},${aimY(yVal).toFixed(1)}`).join(" ");
  }

  function renderAimSlider(aimVal) {
    const t = getT();
    const caution = 0.85;
    const stops = [
      { v: 0.5,  label: t.z_chest },
      { v: 0.65, label: t.z_upperChest },
      { v: 0.75, label: t.z_shoulders },
      { v: 0.84, label: t.z_neck },
      { v: 1.0,  label: t.z_head }
    ];
    const nearest = stops.reduce((best, cur) =>
      Math.abs(cur.v - aimVal) < Math.abs(best.v - aimVal) ? cur : best
    );
    const isRisk = aimVal >= caution;
    const yPos = aimY(aimVal);
    const pctStr = Math.round(((aimVal - 0.5) / 0.5) * 100) + "%";

    const headPoly = polyPoints([
      [34, 1.02], [50, 1.02], [58, 0.995], [58, 0.925],
      [49, 0.875], [35, 0.875], [26, 0.925], [26, 0.995]
    ]);
    const torsoPoly = polyPoints([
      [37, 0.89], [47, 0.89], [48, 0.82], [66, 0.79],
      [78, 0.755], [81, 0.72], [76, 0.4], [8, 0.4],
      [3, 0.72], [6, 0.755], [18, 0.79], [36, 0.82]
    ]);

    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div style="display:flex;align-items:flex-end;justify-content:space-between;gap:12px">
          <span class="ph-label" style="font-size:10px">${esc(t.aimHeight)}</span>
          <span style="display:flex;align-items:baseline;gap:10px">
            <span class="ph-aim__zone" ${isRisk ? 'data-risk=""' : ""}>${esc(nearest.label)}</span>
            <span class="ph-slider__value" style="${isRisk ? "color:var(--ph-bad-text)" : ""}">${pctStr}</span>
          </span>
        </div>

        <div class="ph-aim" id="ph-aim-slider" ${isRisk ? 'data-risk=""' : ""} style="height:188px">
          <svg class="ph-aim__fig" width="84" height="188" viewBox="0 0 84 188" aria-hidden="true">
            <defs>
              <pattern id="aimhatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <rect width="1.6" height="5" class="ph-aim__hatch"></rect>
              </pattern>
              <linearGradient id="aimgrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0.6" stop-color="#fff"></stop>
                <stop offset="1" stop-color="#000"></stop>
              </linearGradient>
              <mask id="aimmask">
                <rect width="84" height="188" fill="url(#aimgrad)"></rect>
              </mask>
              <clipPath id="aimclip">
                <polygon points="${torsoPoly}"></polygon>
                <polygon points="${headPoly}"></polygon>
              </clipPath>
            </defs>
            <g mask="url(#aimmask)">
              <polygon class="ph-aim__body" points="${torsoPoly}"></polygon>
              <polygon class="ph-aim__body" points="${headPoly}"></polygon>
            </g>
            <rect width="84" height="${aimY(caution)}" fill="url(#aimhatch)" clip-path="url(#aimclip)"></rect>
          </svg>

          <div class="ph-aim__rail" style="top:10px;bottom:10px"></div>
          <div class="ph-aim__risk" style="top:10px;height:${aimY(caution) - 10}px"></div>
          <div class="ph-aim__fill" style="top:${yPos}px;height:${178 - yPos}px;--cut:${aimY(caution) - yPos}px"></div>
          <div class="ph-aim__line" style="top:${yPos}px"></div>
          <div class="ph-aim__reticle" style="top:${yPos}px"></div>
          <div class="ph-aim__thumb" style="top:${yPos}px"></div>
          <div class="ph-aim__pad" id="ph-aim-pad" role="slider" tabindex="0" aria-label="${esc(t.aimHeight)}" aria-valuemin="0.5" aria-valuemax="1" aria-valuenow="${aimVal}"></div>

          ${stops
            .map((s) => {
              const pressed = s.v === nearest.v;
              const sPct = Math.round(((s.v - 0.5) / 0.5) * 100) + "%";
              return `
                <button type="button" class="ph-aim__stop" data-aim-stop="${s.v}" aria-pressed="${pressed}" ${s.v >= caution ? 'data-risk=""' : ""} style="top:${aimY(s.v)}px">
                  <span class="ph-aim__name">${esc(s.label)}</span>
                  <span class="ph-aim__pct">${sPct}</span>
                </button>
              `;
            })
            .join("")}
        </div>

        ${
          isRisk
            ? `<div class="ph-aim__note" role="status">${iconSvg("alert", { size: 14, strokeWidth: 2.4 })}<span>${esc(t.aimCaution)}</span></div>`
            : ""
        }
      </div>
    `;
  }

  function renderSpeedSlider(scaleVal) {
    const t = getT();
    const caution = 140;
    const presets = [100, 110, 120, 130, 140, 150];
    const pct = ((scaleVal - 100) / 50) * 100;
    const cautionPct = ((caution - 100) / 50) * 100;
    const isRisk = scaleVal >= caution;
    const fmt = (v) => "×" + (v / 100).toFixed(1);

    return `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;align-items:flex-end;justify-content:space-between">
          <span class="ph-label" style="font-size:10px">${esc(t.speedScale)}</span>
          <span class="ph-slider__value" style="${isRisk ? "color:var(--ph-bad-text)" : ""}">${fmt(scaleVal)}</span>
        </div>
        <div class="ph-slider" id="ph-speed-slider" role="slider" tabindex="0" aria-valuemin="1.0" aria-valuemax="1.5" aria-valuenow="${scaleVal / 100}">
          <div class="ph-slider__track"></div>
          <div class="ph-slider__fill" style="inset-inline-start:${cautionPct}%;width:${100 - cautionPct}%;background:color-mix(in oklch, var(--ph-bad) 55%, transparent)"></div>
          ${presets
            .map(
              (p) =>
                `<span class="ph-slider__tick" style="inset-inline-start:${((p - 100) / 50) * 100}%;top:17px;height:14px;margin-inline-start:${p === 150 ? -2 : 0}px"></span>`
            )
            .join("")}
          <div class="ph-slider__fill" style="inset-inline-start:0;width:${pct}%;${isRisk ? "background:var(--ph-bad)" : ""}"></div>
          <div class="ph-slider__thumb" style="inset-inline-start:${pct}%"></div>
        </div>
        <div class="ph-chips" style="grid-template-columns:repeat(6, minmax(0,1fr))">
          ${presets
            .map(
              (p) =>
                `<button type="button" class="ph-chip ph-cut-xs" data-speed-preset="${p}" aria-pressed="${scaleVal === p}" ${p >= caution ? 'data-risk=""' : ""} style="font-stretch:100%">${fmt(p)}</button>`
            )
            .join("")}
        </div>
        ${
          isRisk
            ? `<div class="ph-aim__note" role="status">${iconSvg("alert", { size: 14, strokeWidth: 2.4 })}<span>${esc(t.speedCaution)}</span></div>`
            : ""
        }
      </div>
    `;
  }

  function renderAngleSlider(yawDeg) {
    const t = getT();
    const presets = [-90, 0, 90, 180];
    const pct = (yawDeg + 180) / 3.6;

    return `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;align-items:flex-end;justify-content:space-between">
          <span class="ph-label" style="font-size:10px">${esc(t.wallAngle)}</span>
          <span class="ph-slider__value">${formatAngle(yawDeg)}</span>
        </div>
        <div class="ph-slider" id="ph-angle-slider" role="slider" tabindex="0" aria-valuemin="-180" aria-valuemax="180" aria-valuenow="${yawDeg}">
          <div class="ph-slider__track"></div>
          ${[0, 25, 50, 75, 100]
            .map(
              (tk) =>
                `<span class="ph-slider__tick" style="inset-inline-start:${tk}%;top:${tk === 50 ? 12 : tk % 50 ? 17 : 14}px;height:${tk === 50 ? 24 : tk % 50 ? 14 : 20}px;margin-inline-start:${tk === 100 ? -2 : tk === 50 ? -1 : 0}px"></span>`
            )
            .join("")}
          <div class="ph-slider__fill" style="inset-inline-start:${Math.min(50, pct)}%;width:${Math.abs(pct - 50)}%"></div>
          <div class="ph-slider__thumb" style="inset-inline-start:${pct}%"></div>
        </div>
        <div class="ph-chips">
          ${presets
            .map(
              (p) =>
                `<button type="button" class="ph-chip ph-cut-xs" data-angle-preset="${p}" aria-pressed="${yawDeg === p}" style="font-stretch:100%">${formatAngle(p)}</button>`
            )
            .join("")}
        </div>
      </div>
    `;
  }

  function renderFeaturesTab() {
    const t = getT();
    const f = state.me.features;

    const defs = {
      marker: {
        saveId: "marker",
        name: t.f_marker,
        description: t.d_marker,
        checked: f.marker.enabled,
        trayHtml: `
          <span class="ph-label">${esc(t.markStyle)}</span>
          <div role="radiogroup" class="ph-chips" style="grid-template-columns:repeat(4, minmax(0,1fr))">
            ${MARKER_TYPES.map((mType) => {
              const lbl = mType === "Dreamland" ? "Dream" : mType;
              const sel = f.marker.type === mType;
              return `<button type="button" role="radio" aria-checked="${sel}" aria-pressed="${sel}" class="ph-chip ph-cut-xs" data-marker-type="${esc(mType)}"><span style="overflow:hidden;text-overflow:ellipsis">${esc(lbl)}</span></button>`;
            }).join("")}
          </div>
        `
      },
      aimpoint: {
        saveId: "aimpoint",
        name: t.f_aimpoint,
        description: t.d_aimHeight,
        checked: f.aimpoint.enabled,
        trayHtml: renderAimSlider(f.aimpoint.aim)
      },
      speed: {
        saveId: "speed",
        name: t.f_speed,
        description: t.d_speed,
        checked: f.speed.enabled,
        trayHtml: renderSpeedSlider(f.speed.scale)
      },
      aimLag: {
        saveId: "aimlag",
        name: t.f_aimlag,
        description: t.d_aimlag,
        checked: f.aimLag.enabled,
        trayHtml: `
          <button type="button" class="ph-subswitch ph-cut-sm" role="switch" aria-checked="${f.aimLag.onFire}" data-aimlag-sub="onFire">
            <span>${esc(t.whenFiring)}</span>
            ${switchHtml({ checked: f.aimLag.onFire, size: "sm", asIndicator: true })}
          </button>
          <button type="button" class="ph-subswitch ph-cut-sm" role="switch" aria-checked="${f.aimLag.onScope}" data-aimlag-sub="onScope">
            <span>${esc(t.whenScoping)}</span>
            ${switchHtml({ checked: f.aimLag.onScope, size: "sm", asIndicator: true })}
          </button>
        `
      },
      gloo: {
        saveId: "gloo",
        name: t.f_gloo,
        description: t.d_gloo,
        checked: f.gloo.enabled,
        trayHtml: renderAngleSlider(f.gloo.yawDeg)
      },
      fastRevive: {
        saveId: "revive",
        name: t.f_revive,
        description: t.d_revive,
        checked: f.fastRevive.enabled,
        trayHtml: ""
      }
    };

    const items = DEFAULT_UI.map((c) => ({ c, def: defs[c.id] })).filter((x) => x.def);
    const activeCount = items.filter((x) => x.def.checked).length;

    return `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:2px 2px 4px">
          <span style="font:var(--ph-type-body);color:var(--ph-text-5)">${esc(t.featuresSub)}</span>
          <span class="ph-display" dir="ltr" style="font-size:15px;color:var(--ph-accent-text)">${activeCount}/${items.length}</span>
        </div>

        ${items
          .map(({ c, def }, idx) => {
            const isSaving = state.savingFeatureId === def.saveId;
            const isOn = Boolean(def.checked);
            const tagLabel = c.tag ? t[`tag_${c.tag}`] || c.tag : null;
            return `
              <div class="ph-feature ph-cut-md" ${isOn ? 'data-on=""' : ""}>
                <div class="ph-feature__body ph-cut-md">
                  <div class="ph-feature__head" data-toggle-feature="${esc(c.id)}">
                    <div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:6px">
                      <div style="display:flex;align-items:center;flex-wrap:wrap;gap:8px">
                        <span class="ph-feature__index" dir="ltr">${String(idx + 1).padStart(2, "0")}</span>
                        <span class="ph-feature__name">${esc(def.name)}</span>
                        ${tagLabel ? tagHtml(tagLabel, c.tag) : ""}
                      </div>
                      <div class="ph-feature__desc">${esc(def.description)}</div>
                      ${
                        isSaving
                          ? `<div class="ph-feature__meta">${spinnerHtml(12)}<span>${esc(t.saving)}</span></div>`
                          : ""
                      }
                    </div>
                    ${switchHtml({ checked: isOn, saving: isSaving, asIndicator: true })}
                  </div>

                  ${
                    def.trayHtml
                      ? `<div class="ph-feature__tray">
                          ${
                            !isOn
                              ? `<div class="ph-label" style="font-size:10px;color:var(--ph-text-7);display:flex;align-items:center;gap:7px">
                                  ${iconSvg("lock", { size: 12, strokeWidth: 2.6 })}
                                  <span>${esc(t.lockedHint)}</span>
                                </div>`
                              : ""
                          }
                          <div class="ph-feature__opts" aria-disabled="${!isOn}">
                            ${def.trayHtml}
                          </div>
                        </div>`
                      : ""
                  }
                </div>
              </div>
            `;
          })
          .join("")}
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Tab 3: Manage View & Update Notes Sub-View
  // --------------------------------------------------------------------------
  function renderManageTab() {
    const t = getT();
    const accounts = (state.me.accounts || []).slice(0, 5);
    const count = accounts.length;
    const latestNote = UPDATE_NOTES[0];

    const openSlotHtml = (first) => `
      <div style="display:flex;align-items:center;gap:12px;opacity:${first ? 1 : 0.55}">
        <div style="width:44px;height:44px;flex:none;border-radius:8px;background:var(--ph-surface-3);display:flex;align-items:center;justify-content:center;color:var(--ph-text-8)">
          ${iconSvg("lock", { size: 18 })}
        </div>
        <div style="display:flex;flex-direction:column;gap:2px;min-width:0">
          <span style="font:var(--ph-type-row-title);text-transform:none;color:var(--ph-text-4)">${esc(first ? t.notLinkedYet : t.slotOpenT)}</span>
          <span class="ph-row__sub">${esc(first ? t.notLinkedSub : t.slotOpenB)}</span>
        </div>
      </div>
    `;

    const accountRowHtml = (acc, isFirst) => {
      const boxSz = isFirst ? 52 : 44;
      const initial = (acc.nick || "?").slice(0, 1).toUpperCase();
      const meta = [acc.level != null ? `${t.lvl} ${acc.level}` : null, acc.region, `#${acc.uid}`]
        .filter(Boolean)
        .join("  ·  ");

      return `
        <div style="position:relative;display:flex;align-items:center;gap:12px;overflow:hidden;border-radius:10px;${
          isFirst
            ? "padding:6px;background:linear-gradient(125deg, color-mix(in oklch, var(--ph-accent) 10%, transparent), transparent 70%)"
            : ""
        }">
          <div style="position:relative;z-index:1;width:${boxSz}px;height:${boxSz}px;flex:none;border-radius:8px;overflow:hidden;background:var(--ph-surface-3);display:flex;align-items:center;justify-content:center;font:var(--ph-type-row-title)">
            <span style="opacity:0.75">${esc(initial)}</span>
          </div>
          <div style="position:relative;z-index:1;display:flex;flex-direction:column;gap:2px;min-width:0">
            <span style="font:var(--ph-type-row-title);text-transform:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" dir="auto">
              ${esc(acc.nick || `#${acc.uid}`)}
            </span>
            <span class="ph-row__sub" dir="ltr">${esc(meta)}</span>
          </div>
        </div>
      `;
    };

    return `
      <div style="display:flex;flex-direction:column;gap:10px;min-height:100%">
        <div class="ph-frame ph-cut-lg">
          <div class="ph-cut-lg" style="padding:16px;display:flex;flex-direction:column;gap:14px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
              <span class="ph-label">${esc(t.linkedAccounts)}</span>
              ${tagHtml(`${count}/5`, count >= 5 ? "new" : undefined)}
            </div>

            ${
              count === 0
                ? openSlotHtml(true)
                : accounts
                    .map(
                      (a, idx) =>
                        `${idx > 0 ? `<div style="height:1px;background:var(--ph-line-2)"></div>` : ""}${accountRowHtml(a, idx === 0)}`
                    )
                    .join("")
            }

            ${
              count > 0 && count < 5
                ? `<div style="height:1px;background:var(--ph-line-2)"></div>${openSlotHtml(false)}`
                : ""
            }

            <span class="ph-row__sub">${esc(t.keyManyAccounts.replace("{n}", "5"))}</span>
          </div>
        </div>

        <button class="ph-row ph-cut-sm" data-action="open-notes" style="flex-direction:column;align-items:stretch;gap:8px;padding:14px 16px;min-height:0">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span class="ph-label">${esc(t.updates)}</span>
            <span style="display:flex;align-items:center;gap:6px;color:var(--ph-text-6)">
              <span class="ph-label" style="font-size:10px">${esc(t.allUpdates)}</span>
              ${iconSvg("chevron", { size: 16, flip: true })}
            </span>
          </div>
          <div style="display:flex;align-items:baseline;gap:10px">
            <span class="ph-display" dir="ltr" style="font-size:20px;color:var(--ph-accent-text)">${esc(latestNote.version)}</span>
            <span style="font:var(--ph-type-row-title);text-transform:uppercase">${esc(latestNote.title)}</span>
          </div>
          <span style="font:var(--ph-type-body);color:var(--ph-text-5);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-align:start">
            ${esc(latestNote.body)}
          </span>
        </button>

        <div class="ph-label" style="padding:8px 2px 2px">${esc(t.community)}</div>

        <a class="ph-row ph-cut-sm" href="#discord" onclick="event.preventDefault()">
          <span class="ph-row__icon ph-cut-xs">D</span>
          <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
            <span class="ph-row__title">Discord</span>
          </span>
          <span class="ph-row__trail">${iconSvg("external", { size: 16, flip: true })}</span>
        </a>

        <a class="ph-row ph-cut-sm" href="#whatsapp" onclick="event.preventDefault()">
          <span class="ph-row__icon ph-cut-xs">W</span>
          <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
            <span class="ph-row__title">WhatsApp</span>
          </span>
          <span class="ph-row__trail">${iconSvg("external", { size: 16, flip: true })}</span>
        </a>

        <div style="margin-top:auto;padding-top:22px">
          <button class="ph-btn ph-cut-sm ph-btn--danger-soft ph-btn--block" data-action="logout">
            ${iconSvg("logout", { size: 16, strokeWidth: 2.2, flip: true })}
            <span>${esc(t.logout)}</span>
          </button>
        </div>
      </div>
    `;
  }

  function renderUpdateNotesView() {
    return `
      <div style="display:flex;flex-direction:column;gap:10px">
        ${UPDATE_NOTES.map(
          (note, idx) => `
          <div class="ph-feature ph-cut-md">
            <div class="ph-feature__body ph-cut-md" style="padding:16px;display:flex;flex-direction:column;gap:6px">
              <div style="display:flex;align-items:baseline;gap:10px">
                <span class="ph-display" dir="ltr" style="font-size:24px;color:${idx === 0 ? "var(--ph-accent-text)" : "var(--ph-text-4)"}">${esc(note.version)}</span>
                <span style="font:var(--ph-type-row-title);text-transform:uppercase">${esc(note.title)}</span>
              </div>
              <p style="font:var(--ph-type-body);color:var(--ph-text-5)">${esc(note.body)}</p>
            </div>
          </div>
        `
        ).join("")}
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Root View 3: Authenticated Dashboard Shell
  // --------------------------------------------------------------------------
  function renderDashboard() {
    const t = getT();
    const me = state.me;
    const inSub = state.subView !== null;
    const title = inSub
      ? state.subView === "notes"
        ? t.updates
        : t.guide
      : state.tab === "features"
      ? t.features
      : state.tab === "manage"
      ? t.manage
      : t.home;

    const isLocked = me.lock_until && new Date(me.lock_until).getTime() > Date.now();
    const canConnect = (me.status === "active" || me.thaw) && !isLocked;
    const showFirstSetup = canConnect && me.last_seen_at == null;

    let mainBody = "";
    if (state.subView === "notes") {
      mainBody = renderUpdateNotesView();
    } else if (state.subView === "guide") {
      mainBody = renderSetupWizard({ asGuide: true });
    } else if (state.tab === "home") {
      mainBody = showFirstSetup ? renderSetupWizard({ asGuide: false }) : renderHomeStatus();
    } else if (state.tab === "features") {
      mainBody = renderFeaturesTab();
    } else if (state.tab === "manage") {
      mainBody = renderManageTab();
    }

    const showConnectDock =
      !inSub && state.tab === "home" && !showFirstSetup && canConnect && !me.online;

    const tabs = [
      { id: "home",     label: t.home,     icon: "home" },
      { id: "features", label: t.features, icon: "features" },
      { id: "manage",   label: t.manage,   icon: "manage" }
    ];

    return `
      <div class="ph-viewport">
        <div class="ph-app" style="height:100dvh;width:100%;display:flex;flex-direction:column;position:relative">
          ${headerHtml({ title, showBack: inSub, showBell: true })}

          <main class="ph-view" style="flex:1;overflow-y:auto;padding:${state.tab !== "home" || inSub ? "4px 14px 8px" : "0 16px 8px"}">
            ${mainBody}
          </main>

          ${
            showConnectDock
              ? `
              <div class="ph-connect-dock">
                <button class="ph-connect ph-cut-md" data-action="connect-sub" ${state.connectBusy ? 'disabled aria-busy="true"' : ""}>
                  <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
                    <span class="ph-connect__label">${esc(t.connect)}</span>
                    <span class="ph-connect__sub">${esc(state.connectBusy ? t.opening : t.connectSub)}</span>
                  </span>
                  <span class="ph-connect__icon ph-cut-sm">
                    ${state.connectBusy ? spinnerHtml(20) : iconSvg("plus", { size: 26, strokeWidth: 2.8 })}
                  </span>
                </button>
              </div>
              ${
                state.connectHint
                  ? `<div role="status" style="text-align:center;padding:0 16px 6px;font:var(--ph-type-body-sm);color:${state.connectHint.bad ? "var(--ph-bad-text)" : "var(--ph-text-5)"}">${esc(state.connectHint.text)}</div>`
                  : ""
              }
              `
              : ""
          }

          ${
            !inSub
              ? `<nav class="ph-tabbar" role="tablist" style="--n:3">
                  ${tabs
                    .map(
                      (tb) => `
                      <button role="tab" aria-selected="${tb.id === state.tab}" class="ph-tab" data-tab="${tb.id}">
                        ${iconSvg(tb.icon, { size: 22 })}
                        <span>${esc(tb.label)}</span>
                      </button>
                    `
                    )
                    .join("")}
                </nav>`
              : ""
          }

          <div class="ph-scanlines"></div>
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // Floating Demo Sandbox Switcher (Explore Every Screen & Theme in 1 Click)
  // --------------------------------------------------------------------------
  function renderDemoSwitcher() {
    const presets = [
      { id: "gate",        label: "Key Gate (Login)" },
      { id: "active",      label: "HUD: Connected" },
      { id: "offline",     label: "HUD: Offline + Dock" },
      { id: "setup",       label: "Home: Setup Wizard" },
      { id: "locked",      label: "HUD: Locked Timer" },
      { id: "expired",     label: "HUD: Expired Key" },
      { id: "paused",      label: "HUD: Paused Key" },
      { id: "maintenance", label: "Maintenance Screen" },
      { id: "kicked",      label: "Gate: Kicked Alert" }
    ];

    return `
      <button class="ph-demo-fab ph-cut-xs" data-action="toggle-demo-panel">
        <span class="ph-demo-fab__dot"></span>
        <span>Demo Controls</span>
      </button>
      ${
        state.demoPanelOpen
          ? `<div class="ph-demo-panel ph-cut-sm">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span class="ph-label" style="color:var(--ph-text-2)">Preview States</span>
                <button data-action="toggle-demo-panel" style="background:none;border:0;color:var(--ph-text-5);cursor:pointer;font-size:12px">✕</button>
              </div>
              <div class="ph-demo-grid">
                ${presets
                  .map(
                    (p) =>
                      `<button class="ph-demo-btn ph-cut-xs" data-demo-preset="${p.id}" data-active="${state.presetName === p.id}">${esc(p.label)}</button>`
                  )
                  .join("")}
              </div>
              <div class="ph-label" style="color:var(--ph-text-2);margin-top:4px">Brand Themes (CSS [data-brand])</div>
              <div class="ph-demo-grid">
                ${BRANDS.map(
                  (b) =>
                    `<button class="ph-demo-btn ph-cut-xs" data-demo-brand="${b.slug}" data-active="${state.brand === b.slug}">
                      <span style="display:inline-block;width:7px;height:7px;background:${b.accent};margin-right:4px"></span>${esc(b.name)}
                    </button>`
                ).join("")}
              </div>
              <div style="color:var(--ph-text-6);font-size:11px;line-height:1.4">
                Tip: Press <code style="color:var(--ph-text-2)">Spacebar</code> once (<code style="color:var(--ph-text-2)">" "</code>) and click UNLOCK (or press Enter)!
              </div>
            </div>`
          : ""
      }
    `;
  }

  // --------------------------------------------------------------------------
  // Actions & API Calls (with Automatic Local Fallback)
  // --------------------------------------------------------------------------
  async function apiRequest(path, options = {}) {
    try {
      const res = await fetch(path, {
        headers: { "Content-Type": "application/json" },
        ...options
      });
      if (!res.ok && res.status === 404) return null; // static host fallback
      const json = await res.json().catch(() => ({}));
      return { status: res.status, ok: res.ok, data: json };
    } catch {
      return null;
    }
  }

  function triggerKeyShake(errText) {
    state.keyError = errText;
    state.keyShake = true;
    render();
    setTimeout(() => {
      state.keyShake = false;
      const box = document.querySelector(".ph-keyinput");
      if (box) box.removeAttribute("data-shake");
    }, 400);
  }

  async function handleUnlockSubmit(e) {
    if (e) e.preventDefault();
    const t = getT();

    // Read raw value directly without .trim() so a single space (" ") is preserved
    const fieldEl = document.getElementById("ph-key-field");
    const rawKey = fieldEl ? fieldEl.value : state.keyInput;
    state.keyInput = rawKey;

    if (rawKey.length === 0) {
      triggerKeyShake(t.err_incomplete);
      return;
    }

    if (rawKey !== " ") {
      triggerKeyShake(t.err_invalid);
      return;
    }

    state.unlocking = true;
    state.keyError = null;
    render();

    // Try backend /api/redeem if running via node server.js, otherwise local resolution
    const apiRes = await apiRequest("/api/redeem", {
      method: "POST",
      body: JSON.stringify({ key: rawKey })
    });

    await new Promise((r) => setTimeout(r, 250));
    state.unlocking = false;

    if (apiRes) {
      if (!apiRes.ok) {
        triggerKeyShake(apiRes.data?.error || t.err_invalid);
        return;
      }
      if (apiRes.data.maintenance) {
        state.rootView = "maintenance";
        state.presetName = "maintenance";
      } else {
        state.me = apiRes.data.me;
        state.me.features = mergeFeatures(state.me.features);
        state.rootView = "dashboard";
        state.presetName = apiRes.data.preset || "active";
        state.tab = "home";
        state.subView = null;
        connectEventStream();
      }
      persistSession();
      render();
      return;
    }

    // Pure client-side fallback
    const resolved = resolveKeyPreset(rawKey);
    if (!resolved.valid) {
      triggerKeyShake(t.err_invalid);
      return;
    }
    state.me = createProfile(resolved.preset, rawKey);
    state.rootView = "dashboard";
    state.presetName = resolved.preset;
    state.tab = "home";
    state.subView = null;
    persistSession();
    render();
  }

  async function saveFeatures(saveId, nextFeatures) {
    state.me.features = mergeFeatures(nextFeatures);
    state.savingFeatureId = saveId;
    persistSession();
    render();

    await apiRequest("/api/features", {
      method: "PATCH",
      body: JSON.stringify({ features: state.me.features })
    });

    setTimeout(() => {
      if (state.savingFeatureId === saveId) {
        state.savingFeatureId = null;
        render();
      }
    }, 260);
  }

  async function handleConnectSub() {
    const t = getT();
    state.connectBusy = true;
    state.connectHint = null;
    render();

    const endpoint = state.me?.linked ? "/api/relink" : "/api/link";
    const apiRes = await apiRequest(endpoint, { method: "POST" });
    await new Promise((r) => setTimeout(r, 500));

    state.connectBusy = false;
    const subUrl = apiRes?.data?.url || "https://ph4nt0m.lol/sub/active-session";
    state.mintedUrl = subUrl;
    state.needAppFallback = true;
    state.connectHint = {
      bad: false,
      text: `hiddify://import/${subUrl}#PHANTOM — ${t.setup2Hint}`
    };
    render();
  }

  async function handleLogout() {
    await apiRequest("/api/logout", { method: "POST" });
    if (eventSource) {
      eventSource.close();
      eventSource = null;
    }
    state.rootView = "gate";
    state.presetName = "gate";
    state.me = null;
    state.subView = null;
    state.tab = "home";
    persistSession();
    render();
  }

  function applyDemoPreset(presetId) {
    state.presetName = presetId;
    state.subView = null;
    state.connectHint = null;
    state.needAppFallback = false;

    if (presetId === "gate") {
      state.rootView = "gate";
      state.gateMaintenance = false;
      state.kickedBanner = false;
      state.me = null;
    } else if (presetId === "kicked") {
      state.rootView = "gate";
      state.gateMaintenance = true;
      state.kickedBanner = true;
      state.me = null;
    } else if (presetId === "maintenance") {
      state.rootView = "maintenance";
      state.me = createProfile("active");
    } else {
      state.rootView = "dashboard";
      state.me = createProfile(presetId);
      state.tab = "home";
    }
    persistSession();
    render();
  }

  function connectEventStream() {
    if (typeof EventSource === "undefined") return;
    try {
      if (eventSource) eventSource.close();
      eventSource = new EventSource("/api/events");
      eventSource.addEventListener("logout", () => {
        eventSource.close();
        eventSource = null;
        try {
          localStorage.setItem(STORAGE_KEYS.KICKED, "1");
        } catch {}
        state.kickedBanner = true;
        state.rootView = "gate";
        state.me = null;
        persistSession();
        render();
      });
      eventSource.onerror = () => {
        // Silently close on static file:// or static server
        eventSource?.close();
        eventSource = null;
      };
    } catch {}
  }

  // --------------------------------------------------------------------------
  // Pointer Drag Binding for Sliders (AimSlider, SpeedSlider, AngleSlider)
  // --------------------------------------------------------------------------
  function bindSliders() {
    const aimPad = document.getElementById("ph-aim-pad");
    const aimContainer = document.getElementById("ph-aim-slider");
    if (aimPad && aimContainer) {
      let dragging = false;
      let curVal = state.me.features.aimpoint.aim;

      const calcAim = (clientY) => {
        const rect = aimContainer.getBoundingClientRect();
        const norm = Math.min(1, Math.max(0, 1 - (clientY - rect.top - 10) / (rect.height - 20)));
        return Math.round((0.5 + 0.5 * norm) * 100) / 100;
      };

      const updateAimDom = (v) => {
        curVal = v;
        const y = aimY(v);
        const risk = v >= 0.85;
        if (risk) aimContainer.setAttribute("data-risk", "");
        else aimContainer.removeAttribute("data-risk");
        aimContainer.querySelector(".ph-aim__fill").style.cssText = `top:${y}px;height:${178 - y}px;--cut:${aimY(0.85) - y}px`;
        aimContainer.querySelector(".ph-aim__line").style.top = `${y}px`;
        aimContainer.querySelector(".ph-aim__reticle").style.top = `${y}px`;
        aimContainer.querySelector(".ph-aim__thumb").style.top = `${y}px`;
      };

      aimPad.onpointerdown = (e) => {
        aimPad.setPointerCapture(e.pointerId);
        dragging = true;
        aimContainer.setAttribute("data-drag", "");
        updateAimDom(calcAim(e.clientY));
      };
      aimPad.onpointermove = (e) => {
        if (!dragging) return;
        updateAimDom(calcAim(e.clientY));
      };
      const finishAim = () => {
        if (!dragging) return;
        dragging = false;
        aimContainer.removeAttribute("data-drag");
        saveFeatures("aimpoint", {
          ...state.me.features,
          aimpoint: { ...state.me.features.aimpoint, aim: curVal }
        });
      };
      aimPad.onpointerup = finishAim;
      aimPad.onpointercancel = finishAim;
    }

    const speedSlider = document.getElementById("ph-speed-slider");
    if (speedSlider) {
      let dragging = false;
      let curScale = state.me.features.speed.scale;
      const isRtl = state.lang === "ar";

      const calcSpeed = (clientX) => {
        const rect = speedSlider.getBoundingClientRect();
        let ratio = (clientX - rect.left) / rect.width;
        if (isRtl) ratio = 1 - ratio;
        ratio = Math.min(1, Math.max(0, ratio));
        return 10 * Math.round((100 + 50 * ratio) / 10);
      };

      speedSlider.onpointerdown = (e) => {
        speedSlider.setPointerCapture(e.pointerId);
        dragging = true;
        curScale = calcSpeed(e.clientX);
      };
      speedSlider.onpointermove = (e) => {
        if (!dragging) return;
        curScale = calcSpeed(e.clientX);
        const pct = ((curScale - 100) / 50) * 100;
        const fills = speedSlider.querySelectorAll(".ph-slider__fill");
        const thumb = speedSlider.querySelector(".ph-slider__thumb");
        if (fills[1]) {
          fills[1].style.width = `${pct}%`;
          fills[1].style.background = curScale >= 140 ? "var(--ph-bad)" : "var(--ph-accent)";
        }
        if (thumb) thumb.style.insetInlineStart = `${pct}%`;
      };
      const finishSpeed = () => {
        if (!dragging) return;
        dragging = false;
        saveFeatures("speed", {
          ...state.me.features,
          speed: { ...state.me.features.speed, scale: curScale }
        });
      };
      speedSlider.onpointerup = finishSpeed;
      speedSlider.onpointercancel = finishSpeed;
    }

    const angleSlider = document.getElementById("ph-angle-slider");
    if (angleSlider) {
      let dragging = false;
      let curDeg = state.me.features.gloo.yawDeg;
      const isRtl = state.lang === "ar";

      const calcAngle = (clientX) => {
        const rect = angleSlider.getBoundingClientRect();
        let ratio = (clientX - rect.left) / rect.width;
        if (isRtl) ratio = 1 - ratio;
        ratio = Math.min(1, Math.max(0, ratio));
        return 5 * Math.round((360 * ratio - 180) / 5);
      };

      angleSlider.onpointerdown = (e) => {
        angleSlider.setPointerCapture(e.pointerId);
        dragging = true;
        curDeg = calcAngle(e.clientX);
      };
      angleSlider.onpointermove = (e) => {
        if (!dragging) return;
        curDeg = calcAngle(e.clientX);
        const pct = (curDeg + 180) / 3.6;
        const fill = angleSlider.querySelector(".ph-slider__fill");
        const thumb = angleSlider.querySelector(".ph-slider__thumb");
        if (fill) {
          fill.style.insetInlineStart = `${Math.min(50, pct)}%`;
          fill.style.width = `${Math.abs(pct - 50)}%`;
        }
        if (thumb) thumb.style.insetInlineStart = `${pct}%`;
      };
      const finishAngle = () => {
        if (!dragging) return;
        dragging = false;
        saveFeatures("gloo", {
          ...state.me.features,
          gloo: { ...state.me.features.gloo, yawDeg: curDeg }
        });
      };
      angleSlider.onpointerup = finishAngle;
      angleSlider.onpointercancel = finishAngle;
    }
  }

  // --------------------------------------------------------------------------
  // Render & Delegated Event Listeners
  // --------------------------------------------------------------------------
  function render() {
    const root = document.getElementById("app-root");
    if (!root) return;

    let screenHtml = "";
    if (state.rootView === "maintenance") {
      screenHtml = renderMaintenance();
    } else if (state.rootView === "dashboard" && state.me) {
      screenHtml = renderDashboard();
    } else {
      screenHtml = renderKeyGate();
    }

    root.innerHTML = screenHtml + renderDemoSwitcher();

    // Gate input binding — keep raw characters (including single space " ") without .trim()
    const keyField = document.getElementById("ph-key-field");
    if (keyField) {
      keyField.addEventListener("input", (e) => {
        state.keyInput = e.target.value;
        if (state.keyError) {
          state.keyError = null;
          const errEl = document.querySelector(".ph-fielderror");
          if (errEl) errEl.remove();
          document.querySelector(".ph-keyinput")?.removeAttribute("data-error");
        }
      });

      keyField.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          handleUnlockSubmit(e);
        }
      });
    }

    const gateForm = document.getElementById("ph-gate-form");
    if (gateForm) {
      gateForm.addEventListener("submit", handleUnlockSubmit);
    }

    bindSliders();
  }

  // Live 1-second ticker for HUD countdown & lockout timer without re-rendering full DOM
  function startLiveTicker() {
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = setInterval(() => {
      if (state.rootView !== "dashboard" || !state.me) return;
      const now = Date.now();
      const t = getT();

      const ringEl = document.querySelector("[data-live-ring-time]");
      if (ringEl && state.me.status === "active" && state.me.last_seen_at && state.me.expires_at) {
        const rem = Math.max(0, new Date(state.me.expires_at).getTime() - now);
        ringEl.textContent = formatDuration(rem, t);
      }

      const lockEl = document.querySelector("[data-live-lock]");
      if (lockEl && state.me.lock_until) {
        const remSec = Math.max(0, Math.floor((new Date(state.me.lock_until).getTime() - now) / 1000));
        const lh = Math.floor(remSec / 3600);
        const lm = Math.floor((remSec % 3600) / 60);
        const ls = remSec % 60;
        const pad = (n) => String(n).padStart(2, "0");
        lockEl.textContent = lh > 0 ? `${lh}:${pad(lm)}:${pad(ls)}` : `${pad(lm)}:${pad(ls)}`;
      }
    }, 1000);
  }

  function setupGlobalEvents() {
    document.addEventListener("click", async (e) => {
      if (e.target.closest("[data-stop-prop]")) {
        // Let buttons inside modal trigger actions, but stop backdrop click
        const innerBtn = e.target.closest("[data-action]");
        if (!innerBtn) return;
      }

      const langBtn = e.target.closest("[data-set-lang]");
      if (langBtn) {
        setLang(langBtn.getAttribute("data-set-lang"));
        return;
      }

      const tabBtn = e.target.closest("[data-tab]");
      if (tabBtn) {
        state.tab = tabBtn.getAttribute("data-tab");
        state.subView = null;
        render();
        return;
      }

      const toggleFeat = e.target.closest("[data-toggle-feature]");
      if (toggleFeat) {
        const fId = toggleFeat.getAttribute("data-toggle-feature");
        const cur = state.me.features[fId];
        if (cur) {
          const saveMap = { aimLag: "aimlag", fastRevive: "revive" };
          saveFeatures(saveMap[fId] || fId, {
            ...state.me.features,
            [fId]: { ...cur, enabled: !cur.enabled }
          });
        }
        return;
      }

      const markerBtn = e.target.closest("[data-marker-type]");
      if (markerBtn) {
        const mType = markerBtn.getAttribute("data-marker-type");
        saveFeatures("marker", {
          ...state.me.features,
          marker: { enabled: true, type: mType }
        });
        return;
      }

      const aimStopBtn = e.target.closest("[data-aim-stop]");
      if (aimStopBtn) {
        const v = parseFloat(aimStopBtn.getAttribute("data-aim-stop"));
        saveFeatures("aimpoint", {
          ...state.me.features,
          aimpoint: { ...state.me.features.aimpoint, aim: v }
        });
        return;
      }

      const speedPresetBtn = e.target.closest("[data-speed-preset]");
      if (speedPresetBtn) {
        const sVal = parseInt(speedPresetBtn.getAttribute("data-speed-preset"), 10);
        saveFeatures("speed", {
          ...state.me.features,
          speed: { ...state.me.features.speed, scale: sVal }
        });
        return;
      }

      const anglePresetBtn = e.target.closest("[data-angle-preset]");
      if (anglePresetBtn) {
        const deg = parseInt(anglePresetBtn.getAttribute("data-angle-preset"), 10);
        saveFeatures("gloo", {
          ...state.me.features,
          gloo: { ...state.me.features.gloo, yawDeg: deg }
        });
        return;
      }

      const aimLagSub = e.target.closest("[data-aimlag-sub]");
      if (aimLagSub) {
        const field = aimLagSub.getAttribute("data-aimlag-sub");
        saveFeatures("aimlag", {
          ...state.me.features,
          aimLag: { ...state.me.features.aimLag, [field]: !state.me.features.aimLag[field] }
        });
        return;
      }

      const demoPresetBtn = e.target.closest("[data-demo-preset]");
      if (demoPresetBtn) {
        applyDemoPreset(demoPresetBtn.getAttribute("data-demo-preset"));
        return;
      }

      const demoBrandBtn = e.target.closest("[data-demo-brand]");
      if (demoBrandBtn) {
        setBrand(demoBrandBtn.getAttribute("data-demo-brand"));
        return;
      }

      const actionEl = e.target.closest("[data-action]");
      if (!actionEl) return;
      const action = actionEl.getAttribute("data-action");

      switch (action) {
        case "toggle-lang-menu":
          state.langMenuOpen = !state.langMenuOpen;
          render();
          break;
        case "close-lang-menu":
          state.langMenuOpen = false;
          render();
          break;
        case "open-bell":
          state.bellModalOpen = true;
          render();
          break;
        case "close-bell": {
          const latest = ANNOUNCEMENTS.length ? ANNOUNCEMENTS[0].id : 0;
          state.seenAnnounceId = latest;
          state.bellModalOpen = false;
          try {
            localStorage.setItem(STORAGE_KEYS.SEEN_ANNOUNCE, String(latest));
          } catch {}
          render();
          break;
        }
        case "paste-key":
          try {
            const clip = await navigator.clipboard.readText();
            // Do NOT use .trim() or formatKey() so space character (" ") stays intact
            state.keyInput = clip;
          } catch {
            // Fallback when clipboard permission is blocked in sandboxed iframe
            state.keyInput = " ";
          }
          state.keyError = null;
          render();
          break;
        case "dismiss-kicked":
          state.kickedBanner = false;
          render();
          break;
        case "copy-key":
          if (state.me?.key) {
            navigator.clipboard?.writeText(state.me.key).catch(() => {});
            state.keyCopied = true;
            render();
            setTimeout(() => {
              state.keyCopied = false;
              render();
            }, 1600);
          }
          break;
        case "open-guide":
          state.subView = "guide";
          render();
          break;
        case "open-notes":
          state.subView = "notes";
          render();
          break;
        case "nav-back":
          state.subView = null;
          render();
          break;
        case "connect-sub":
          handleConnectSub();
          break;
        case "copy-sub-link":
          navigator.clipboard?.writeText(state.mintedUrl).catch(() => {});
          state.setupLinkCopied = true;
          render();
          setTimeout(() => {
            state.setupLinkCopied = false;
            render();
          }, 1600);
          break;
        case "logout":
          handleLogout();
          break;
        case "toggle-demo-panel":
          state.demoPanelOpen = !state.demoPanelOpen;
          render();
          break;
      }
    });

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && state.bellModalOpen) {
        const latest = ANNOUNCEMENTS.length ? ANNOUNCEMENTS[0].id : 0;
        state.seenAnnounceId = latest;
        state.bellModalOpen = false;
        render();
      }
    });
  }

  // --------------------------------------------------------------------------
  // Boot / Initialization
  // --------------------------------------------------------------------------
  function init() {
    try {
      const savedLang = localStorage.getItem(STORAGE_KEYS.LANG);
      if (savedLang && window.PHANTOM_I18N[savedLang]) {
        state.lang = savedLang;
      } else {
        const nav = (navigator.language || "en").slice(0, 2);
        state.lang = nav === "ar" ? "ar" : nav === "th" ? "th" : "en";
      }

      const savedBrand = localStorage.getItem(STORAGE_KEYS.BRAND);
      if (savedBrand && BRANDS.some((b) => b.slug === savedBrand)) {
        state.brand = savedBrand;
      }

      state.seenAnnounceId = parseInt(localStorage.getItem(STORAGE_KEYS.SEEN_ANNOUNCE) || "0", 10) || 0;

      if (localStorage.getItem(STORAGE_KEYS.KICKED)) {
        state.kickedBanner = true;
        localStorage.removeItem(STORAGE_KEYS.KICKED);
      }

      const urlKey = new URLSearchParams(window.location.search).get("key");
      if (urlKey !== null) {
        state.keyInput = urlKey;
      }

      const savedSession = localStorage.getItem(STORAGE_KEYS.SESSION);
      if (savedSession) {
        const parsed = JSON.parse(savedSession);
        if (parsed?.rootView && parsed?.me) {
          state.rootView = parsed.rootView;
          state.presetName = parsed.presetName || "active";
          state.me = {
            ...parsed.me,
            features: mergeFeatures(parsed.me.features)
          };
        }
      }
    } catch {}

    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
    document.documentElement.setAttribute("data-brand", state.brand);

    setupGlobalEvents();
    startLiveTicker();
    render();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
