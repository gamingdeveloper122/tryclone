// ============================================================================
// PHANTOM — Brand Config, SVG Icons, Feature Defaults, Changelogs & Helpers
// ============================================================================

window.PHANTOM_DATA = (() => {
  const BRANDS = [
    { slug: "phantom",    name: "PHANTOM",    prefix: "PHTM", accent: "#ededed" },
    { slug: "aimhack",    name: "AIMHACK",    prefix: "AIMH", accent: "#dc2626" },
    { slug: "xreg",       name: "XREG",       prefix: "XREG", accent: "#2d4ded" },
    { slug: "trollmodz",  name: "TROLLMODZ",  prefix: "TRLM", accent: "#38e0f8" },
    { slug: "silentx",    name: "SILENTX",    prefix: "SLTX", accent: "#e01a14" },
    { slug: "zentnityx",  name: "ZENTNITYX",  prefix: "ZNTX", accent: "#b12cdc" },
    { slug: "ruizenteam", name: "RUIZENTEAM", prefix: "RZTM", accent: "#eac836" }
  ];

  const ICONS = {
    home:     '<path d="M4 10 12 3.5 20 10v10h-5.5v-5.5h-5V20H4z" stroke-linejoin="miter"/>',
    features: '<path d="M5 6.5h14l3 3v5l-3 3H5l-3-3v-5z"/><rect x="13" y="9.5" width="5" height="5" fill="currentColor" stroke="none"/>',
    manage:   '<path d="M4 7h16M4 12h16M4 17h10"/>',
    globe:    '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9M12 3c-2.5 2.6-3.8 5.6-3.8 9s1.3 6.4 3.8 9"/>',
    back:     '<path d="m15 5-7 7 7 7"/>',
    chevron:  '<path d="m9 5 7 7-7 7"/>',
    close:    '<path d="M6 6l12 12M18 6 6 18"/>',
    check:    '<path d="m5 12 5 5 9-10"/>',
    copy:     '<rect x="8" y="8" width="12" height="12"/><path d="M16 8V4H4v12h4"/>',
    plus:     '<path d="M12 4v16M4 12h16"/>',
    refresh:  '<path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v5h-5"/>',
    lock:     '<rect x="5" y="11" width="14" height="9"/><path d="M8 11V7h8v4"/>',
    external: '<path d="M7 17 17 7M9 7h8v8"/>',
    logout:   '<path d="M15 4h5v16h-5M10 8l-4 4 4 4M6 12h10"/>',
    phone:    '<rect x="7" y="3" width="10" height="18"/><path d="M11 18h2"/>',
    play:     '<path d="M7 4.5v15l12.5-7.5z" fill="currentColor" stroke="none"/>',
    alert:    '<path d="M12 4v10M12 18v2"/>',
    bell:     '<path d="M6 16V10a6 6 0 0 1 12 0v6l2 3H4zM9.5 19a2.5 2.5 0 0 0 5 0"/>'
  };

  const PHANTOM_GHOST_PATH =
    "M50 4C76 4 92 21 92 46V96L81 86 71 96 60.5 86 50 96 39.5 86 29 96 19 86 8 96V46C8 21 24 4 50 4Z " +
    "M20 42 44 49 42 60 32 64 22 61 18 53Z " +
    "M80 42 56 49 58 60 68 64 78 61 82 53Z " +
    "M50 60 55 69 50 67 45 69Z " +
    "M32 74 38 79 44 74 50 79 56 74 62 79 68 74 68 77.5 62 82.5 56 77.5 50 82.5 44 77.5 38 82.5 32 77.5Z";

  const MARKER_TYPES = [
    "Phantom",
    "Dreamland",
    "Ice Wall",
    "Moco",
    "Clu",
    "Shirou",
    "Iris",
    "Dreki"
  ];

  const DEFAULT_UI = [
    { id: "marker",     tag: "risk" },
    { id: "aimpoint",   tag: "new" },
    { id: "speed",      tag: "new" },
    { id: "aimLag" },
    { id: "gloo" },
    { id: "fastRevive" }
  ];

  const DEFAULT_FEATURES = {
    marker:      { enabled: true,  type: "Phantom" },
    aimpoint:    { enabled: true,  aim: 0.84 },
    speed:       { enabled: false, scale: 100 },
    aimLag:      { enabled: false, onFire: true, onScope: false },
    gloo:        { enabled: false, yawDeg: 180 },
    fastRevive:  { enabled: false },
    fastLanding: { enabled: false, spot: "Peak" }
  };

  function mergeFeatures(raw) {
    return {
      marker:      { ...DEFAULT_FEATURES.marker,      ...(raw?.marker ?? {}) },
      aimpoint:    { ...DEFAULT_FEATURES.aimpoint,    ...(raw?.aimpoint ?? {}) },
      speed:       { ...DEFAULT_FEATURES.speed,       ...(raw?.speed ?? {}) },
      aimLag:      { ...DEFAULT_FEATURES.aimLag,      ...(raw?.aimLag ?? {}) },
      gloo:        { ...DEFAULT_FEATURES.gloo,        ...(raw?.gloo ?? {}) },
      fastRevive:  { ...DEFAULT_FEATURES.fastRevive,  ...(raw?.fastRevive ?? {}) },
      fastLanding: { ...DEFAULT_FEATURES.fastLanding, ...(raw?.fastLanding ?? {}) }
    };
  }

  const UPDATE_NOTES = [
    {
      version: "v1.9",
      title: "faster servers + speed boost",
      body: "we reworked the network and server picking under the hood for lower, steadier ping. phantom also gets a new speed boost card — set your in-match move speed from 1.0 to 1.5x. these updates are still rolling out, so use them at your own risk for now."
    },
    {
      version: "v1.8",
      title: "new app: Hiddify",
      body: "we moved from Happ to Hiddify. open setup on the home screen — install Hiddify, add your key, turn it on. your key and your time are safe, and one key now works on one phone at a time."
    },
    {
      version: "v1.7",
      title: "aim lag is back, next to aimpoint",
      body: "aim lag is back, sitting under aimpoint. run it with aimpoint or on its own. every feature now carries a short description in your own language."
    },
    {
      version: "v1.6",
      title: "aimpoint replaces aim lag",
      body: "new aimpoint: your aim assist locks onto the neck instead of the chest, so shots that used to hit the body land as headshots. one switch, works on every gun, applies from the start of your next match."
    },
    {
      version: "v1.5",
      title: "aim lag paused",
      body: "aim lag is marked risk and switched off in the app while we fix it — the toggle is greyed out for everyone. every other feature is unaffected."
    },
    {
      version: "v1.4",
      title: "fast revive + rebuilt aim lag",
      body: "new fast revive: pick a knocked teammate up in about 100 ms instead of ~3 seconds. aim lag was rebuilt to freeze the target's position instead of dropping packets, so it no longer stutters your own movement."
    },
    {
      version: "v1.3",
      title: "smarter server picking",
      body: "your config now picks the node with the lowest real ping to your own match server, measured every 15 minutes, not the closest one on a map. failed key imports now show the reason right in the app."
    },
    {
      version: "v1.2",
      title: "fast landing + europe node",
      body: "added fast landing: drop straight onto a saved waypoint instead of following the flight path. a france node was added for europe, north africa and the middle east."
    },
    {
      version: "v1.1",
      title: "device lock + stability",
      body: "keys are locked to one device and each account gets its own tunnel. fixed markers dying after the first match and sessions colliding between accounts."
    },
    {
      version: "v1.0",
      title: "initial release",
      body: "key-based access, live marker and aim-lag toggles, and one-tap setup."
    }
  ];

  const ANNOUNCEMENTS = [
    {
      id: 3,
      level: "update",
      title: "v1.9 — Speed Boost & Lower Ping Nodes",
      body: "New Speed Boost slider (1.0x–1.5x) and vertical Aim Height silhouette control are now live in the Features tab."
    },
    {
      id: 2,
      level: "warn",
      title: "Hiddify Client Migration Complete",
      body: "One key works on one phone at a time. Open Setup Guide on the Home screen if you need to re-import your subscription."
    },
    {
      id: 1,
      level: "info",
      title: "Multi-Account Support (Up to 5 Slots)",
      body: "Your key now links up to 5 accounts automatically as you play matches."
    }
  ];

  const APP_STORE_LINKS = {
    HIDDIFY_ANDROID: "https://play.google.com/store/apps/details?id=app.hiddify.com",
    HIDDIFY_IOS:     "https://apps.apple.com/app/id6596777532",
    SINGBOX_ANDROID: "https://play.google.com/store/apps/details?id=io.nekohasekai.sfa",
    SINGBOX_IOS:     "https://apps.apple.com/app/id6785326793"
  };

  function createProfile(preset, customKey) {
    const now = Date.now();
    const day = 86400 * 1000;
    const keyVal = customKey !== undefined && customKey !== null ? customKey : " ";
    const base = {
      key: keyVal,
      status: "active",
      online: true,
      linked: true,
      thaw: false,
      strikes: 0,
      lock_until: null,
      activated_at: new Date(now - 6 * day).toISOString(),
      expires_at: new Date(now + 24 * day + 7 * 3600 * 1000).toISOString(),
      last_seen_at: new Date(now - 42 * 1000).toISOString(),
      device_os: "iOS 18.2",
      device_model: "iPhone 15 Pro",
      accounts: [
        { uid: "4829104721", nick: "PH4NT0M_X", level: 74, region: "SG" },
        { uid: "7190448210", nick: "NULL_DASH", level: 61, region: "ME" }
      ],
      features: mergeFeatures(DEFAULT_FEATURES)
    };

    switch (preset) {
      case "offline":
        return {
          ...base,
          online: false,
          last_seen_at: new Date(now - 18 * 60 * 1000).toISOString()
        };
      case "setup":
        return {
          ...base,
          online: false,
          linked: false,
          thaw: true,
          activated_at: null,
          expires_at: null,
          last_seen_at: null,
          accounts: []
        };
      case "locked":
        return {
          ...base,
          online: false,
          strikes: 1,
          lock_until: new Date(now + 29 * 60 * 1000 + 45 * 1000).toISOString()
        };
      case "expired":
        return {
          ...base,
          status: "expired",
          online: false,
          expires_at: new Date(now - 2 * day).toISOString(),
          last_seen_at: new Date(now - 2 * day).toISOString()
        };
      case "paused":
        return {
          ...base,
          status: "paused",
          online: false
        };
      case "unactivated":
        return {
          ...base,
          status: "unactivated",
          online: false,
          activated_at: null,
          expires_at: null,
          last_seen_at: null,
          accounts: []
        };
      default:
        return base;
    }
  }

  function resolveKeyPreset(rawKey) {
    // Valid access key is strictly a single space character (" ") — no .trim()
    if (rawKey === " ") {
      return { valid: true, preset: "active" };
    }
    return { valid: false };
  }

  function formatKey(raw) {
    // Preserve raw input as-is (including single space " ") without .trim() or stripping
    return String(raw ?? "");
  }

  function isKeyComplete(raw) {
    // Do NOT use .trim() so a single space (" ") is recognized as non-empty
    return String(raw ?? "").length > 0;
  }

  function formatAngle(deg) {
    if (deg === 0) return "0°";
    if (Math.abs(deg) === 180) return "180°";
    return (deg > 0 ? "+" : "−") + Math.abs(deg) + "°";
  }

  function formatDate(iso, lang) {
    const locale = { en: "en-GB", th: "th-TH", ar: "ar-u-nu-latn" }[lang] || "en-GB";
    return new Date(iso).toLocaleDateString(locale, {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }

  function formatDuration(ms, t) {
    if (ms <= 0) return t.expiredWord;
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / 86400);
    const h = Math.floor((totalSec % 86400) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (d > 0) return `${d}${t.u_d} ${h}${t.u_h}`;
    if (h > 0) return `${h}${t.u_h} ${m}${t.u_m}`;
    return `${m}${t.u_m} ${String(s).padStart(2, "0")}${t.u_s}`;
  }

  function relativeTime(timestampMs, t, nowMs = Date.now()) {
    const diffSec = (nowMs - timestampMs) / 1000;
    if (diffSec < 60) return t.justNow;
    if (diffSec < 3600) return String(t.ago_m).replace("{n}", String(Math.floor(diffSec / 60)));
    if (diffSec < 86400) return String(t.ago_h).replace("{n}", String(Math.floor(diffSec / 3600)));
    return String(t.ago_d).replace("{n}", String(Math.floor(diffSec / 86400)));
  }

  function detectOS() {
    if (typeof navigator === "undefined") return "android";
    const ua = navigator.userAgent || "";
    if (/iphone|ipad|ipod/i.test(ua) || (/\bMac/i.test(ua) && "ontouchend" in document)) {
      return "ios";
    }
    return "android";
  }

  return {
    BRANDS,
    ICONS,
    PHANTOM_GHOST_PATH,
    MARKER_TYPES,
    DEFAULT_UI,
    DEFAULT_FEATURES,
    UPDATE_NOTES,
    ANNOUNCEMENTS,
    APP_STORE_LINKS,
    mergeFeatures,
    createProfile,
    resolveKeyPreset,
    formatKey,
    isKeyComplete,
    formatAngle,
    formatDate,
    formatDuration,
    relativeTime,
    detectOS
  };
})();
