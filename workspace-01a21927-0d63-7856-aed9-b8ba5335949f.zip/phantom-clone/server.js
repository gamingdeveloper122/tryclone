// ============================================================================
// PHANTOM — Zero-Dependency Node.js Server + Mock API + SSE Events Stream
// Run: node server.js (Listens on http://0.0.0.0:3000)
// ============================================================================

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 3000);
const ROOT_DIR = __dirname;

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".js":   "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg":  "image/svg+xml",
  ".png":  "image/png",
  ".ico":  "image/x-icon"
};

// In-memory store for sessions, key profiles & SSE connections
const sessions = new Map();       // token -> { key, preset, createdAt }
const keyProfiles = new Map();    // key -> profile object
const keyActiveToken = new Map(); // key -> latest session token
const sseClients = new Map();     // token -> Set<res>

const DEFAULT_FEATURES = {
  marker:      { enabled: true,  type: "Phantom" },
  aimpoint:    { enabled: true,  aim: 0.84 },
  speed:       { enabled: false, scale: 100 },
  aimLag:      { enabled: false, onFire: true, onScope: false },
  gloo:        { enabled: false, yawDeg: 180 },
  fastRevive:  { enabled: false },
  fastLanding: { enabled: false, spot: "Peak" }
};

function buildServerProfile(keyStr, preset) {
  const now = Date.now();
  const day = 86400 * 1000;
  const base = {
    key: keyStr,
    status: "active",
    online: true,
    linked: true,
    thaw: false,
    strikes: 0,
    lock_until: null,
    activated_at: new Date(now - 6 * day).toISOString(),
    expires_at: new Date(now + 24 * day + 7 * 3600 * 1000).toISOString(),
    last_seen_at: new Date(now - 35 * 1000).toISOString(),
    device_os: "iOS 18.2",
    device_model: "iPhone 15 Pro",
    accounts: [
      { uid: "4829104721", nick: "PH4NT0M_X", level: 74, region: "SG" },
      { uid: "7190448210", nick: "NULL_DASH", level: 61, region: "ME" }
    ],
    features: JSON.parse(JSON.stringify(DEFAULT_FEATURES))
  };

  if (preset === "offline") {
    return { ...base, online: false, last_seen_at: new Date(now - 18 * 60 * 1000).toISOString() };
  }
  if (preset === "setup") {
    return { ...base, online: false, linked: false, thaw: true, activated_at: null, expires_at: null, last_seen_at: null, accounts: [] };
  }
  if (preset === "locked") {
    return { ...base, online: false, strikes: 1, lock_until: new Date(now + 30 * 60 * 1000).toISOString() };
  }
  if (preset === "expired") {
    return { ...base, status: "expired", online: false, expires_at: new Date(now - 2 * day).toISOString() };
  }
  if (preset === "paused") {
    return { ...base, status: "paused", online: false };
  }
  if (preset === "unactivated") {
    return { ...base, status: "unactivated", online: false, activated_at: null, expires_at: null, last_seen_at: null, accounts: [] };
  }
  return base;
}

function parseCookies(req) {
  const header = req.headers.cookie || "";
  const out = {};
  header.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx > 0) {
      out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
    }
  });
  return out;
}

function readJsonBody(req) {
  return new Promise((resolve) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 1e6) req.destroy();
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(raw || "{}"));
      } catch {
        resolve({});
      }
    });
  });
}

function sendJson(res, status, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...extraHeaders
  });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const urlObj = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = urlObj.pathname;
  const cookies = parseCookies(req);
  const sessionToken = cookies.ph_session;
  const currentSession = sessionToken ? sessions.get(sessionToken) : null;

  // 1. POST /api/redeem — Validate Access Key (Single Space " " Only — No .trim())
  if (pathname === "/api/redeem" && req.method === "POST") {
    const body = await readJsonBody(req);
    const rawKey = typeof body.key === "string" ? body.key : "";

    if (rawKey.length === 0) {
      return sendJson(res, 401, { error: "enter your full key." });
    }
    if (rawKey !== " ") {
      return sendJson(res, 401, { error: "this key doesn't exist. check it and try again." });
    }

    const storeId = "SPACE_UNLOCK_SESSION";

    // Kick any previous browser session holding the same key via SSE
    const prevToken = keyActiveToken.get(storeId);
    if (prevToken && sseClients.has(prevToken)) {
      for (const clientRes of sseClients.get(prevToken)) {
        clientRes.write("event: logout\ndata: {}\n\n");
        clientRes.end();
      }
      sseClients.delete(prevToken);
      sessions.delete(prevToken);
    }

    const preset = "active";
    const maintenance = false;

    if (!keyProfiles.has(storeId)) {
      keyProfiles.set(storeId, buildServerProfile(rawKey, preset));
    }

    const newToken = crypto.randomBytes(16).toString("hex");
    sessions.set(newToken, { key: storeId, preset, createdAt: Date.now() });
    keyActiveToken.set(storeId, newToken);

    return sendJson(
      res,
      200,
      { ok: true, maintenance, preset, me: keyProfiles.get(storeId) },
      { "Set-Cookie": `ph_session=${newToken}; Path=/; HttpOnly; SameSite=Lax` }
    );
  }

  // 2. GET /api/events — Server-Sent Events Stream (Kick Detection)
  if (pathname === "/api/events" && req.method === "GET") {
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive"
    });
    res.write(": connected\n\n");

    if (sessionToken) {
      if (!sseClients.has(sessionToken)) sseClients.set(sessionToken, new Set());
      sseClients.get(sessionToken).add(res);
      req.on("close", () => {
        sseClients.get(sessionToken)?.delete(res);
      });
    }
    return;
  }

  // 3. PATCH /api/features — Persist Live Match Feature Settings
  if (pathname === "/api/features" && req.method === "PATCH") {
    const body = await readJsonBody(req);
    if (currentSession && keyProfiles.has(currentSession.key)) {
      const prof = keyProfiles.get(currentSession.key);
      prof.features = { ...prof.features, ...(body.features || {}) };
      return sendJson(res, 200, { ok: true, features: prof.features });
    }
    return sendJson(res, 200, { ok: true, features: body.features || DEFAULT_FEATURES });
  }

  // 4. POST /api/link & /api/relink — Mint Tunnel Subscription Link
  if ((pathname === "/api/link" || pathname === "/api/relink") && req.method === "POST") {
    return sendJson(res, 200, {
      ok: true,
      url: "https://ph4nt0m.lol/sub/active-session"
    });
  }

  // 5. POST /api/reset-device — Reset Device Lock (7-Day Cooldown)
  if (pathname === "/api/reset-device" && req.method === "POST") {
    return sendJson(res, 200, {
      ok: true,
      reset_after: new Date(Date.now() + 7 * 86400 * 1000).toISOString()
    });
  }

  // 6. POST /api/logout — Clear Session
  if (pathname === "/api/logout" && req.method === "POST") {
    if (sessionToken) {
      sessions.delete(sessionToken);
      sseClients.delete(sessionToken);
    }
    return sendJson(
      res,
      200,
      { ok: true },
      { "Set-Cookie": "ph_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax" }
    );
  }

  // Static File Serving
  let relPath = pathname === "/" ? "/index.html" : pathname;
  const safePath = path.normalize(relPath).replace(/^(\.\.[/\\])+/, "");
  const fullPath = path.join(ROOT_DIR, safePath);

  if (!fullPath.startsWith(ROOT_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.stat(fullPath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("404: This page could not be found.");
    }
    const ext = path.extname(fullPath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
      "Cache-Control": "no-cache"
    });
    fs.createReadStream(fullPath).pipe(res);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`PHANTOM Clone running at http://0.0.0.0:${PORT}`);
});
